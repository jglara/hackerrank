module Fences where

import qualified Data.Vector.Unboxed as V
import qualified Data.Vector.Unboxed.Mutable as MV

norm ::  V.Vector Double -> Double
norm = sqrt . V.sum . V.map (\x -> x*x)


--import Data.List
--rectangle :: Int -> [Int] -> Int
--rectangle k = maximum. map ((*k) . length) . filter (elem False) . group . map (<k)
--
--solve :: [Int] -> Int
--solve xs = maximum . map (`rectangle` xs) $ xs

solve :: [Int] -> Int
solve xs = snd . head . reduceFences 1 $ xs'
           where xs' = map (\x -> (x,x)) xs

reduceFences :: Int -> [(Int,Int)] -> [(Int,Int)]
reduceFences _ [] = []
reduceFences _ [x] = [x]
reduceFences n xs = reduceFences (n+1) $ (zipWith (reduce2 (n+1)) <*> tail) xs

reduce2 :: Int -> (Int, Int) -> (Int, Int) -> (Int, Int)
reduce2 n (min_height, max_rect) (min_height', max_rect') = let new_min = min min_height min_height'
                                                            in (new_min, maximum [new_min * n, max_rect, max_rect'])

fences :: String -> String
fences = (++ "\n") . show . solve . map read . words . (!! 1) . lines
