module Main where

import qualified Fences (fences)

main :: IO ()
main = interact Fences.fences
